#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"


void test_nice()
{
    int pid, nice;

    printf("case 1. get nice value of init process: ");
        if (getnice(1) == 5)  
            printf("OK\n");
        else
            printf("WRONG\n");

        printf("case 2. get nice value of non-existing process: ");
        if (getnice(20) == -1) 
            printf("OK\n");
        else
            printf("WRONG\n");

        printf("case 3. set nice value of current process: ");
        pid = getpid();
        setnice(pid, 3); 
        if (getnice(pid) == 3)  
            printf("OK\n");
        else
            printf("WRONG\n");

        printf("case 4. set nice value of non-existing process: ");
        if (setnice(100, 3) == -1) 
            printf("OK\n");
        else
            printf("WRONG\n");

        printf("case 5. set wrong nice value of current process: ");
        if (setnice(pid, -1) == -1 && setnice(pid, 31) == -1) 
            printf("OK\n");
        else
            printf("WRONG\n");
    
        printf("case 6. get nice value of forked process: ");
        nice = getnice(pid);

        pid = fork();
        if (pid == 0) { //child
            if (getnice(getpid()) == nice) { 
                printf("OK\n");
                exit(0);
            }   
            else { 
                printf("WRONG\n");
                exit(0);
            }   
        }   
        else                        //parent
            wait(0);
}

int main(int argc, char **argv)
{
        printf("=== TEST START ===\n");
        test_nice();
        printf("=== TEST   END ===\n");

        exit(0);
}

