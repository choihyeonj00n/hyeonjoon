#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fcntl.h"

int main(int argc, char *argv[])
{
  int pid;

  if(argc < 2){
	printf("Wrong use of getnice\n");
	exit(1);
  }
  pid = atoi(argv[1]);
  getnice(pid);
  exit(0);
}
